from django.apps import AppConfig


class DjangoSummernoteConfig(AppConfig):
    name = 'django_summernote'
    verbose_name = 'Django Summernote'
